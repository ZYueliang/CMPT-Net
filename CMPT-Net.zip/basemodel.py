import torch
import torch.nn as nn
import torch.optim as optim
import math
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from utils import *

def pad_and_batch(traj):
    padded_trajectories =torch.nn.utils.rnn.pad_sequence(traj,padding_value=0)#pad_sequence用0来填充轨迹
    return padded_trajectories

class TrajectoryLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim, batch_first=True):
        super(TrajectoryLSTM, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=batch_first)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        out, _ = self.lstm(x, (h0.detach(), c0.detach()))
        out = self.fc(out[:, -1, :])
        return out

#GAT模型定义
class GATModel(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(GATModel, self).__init__()
        self.hidden_dim = hidden_dim
        self.attention = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Softmax(dim=1)
        )
    def forward(self, x, adj_matrix):
        attention_weights = self.attention(x)
        adjacency_matrix_expanded = adj_matrix.unsqueeze(0).repeat(x.shape[0], 1, 1)
        weighted_values = torch.matmul(attention_weights, adjacency_matrix_expanded)
        output = torch.sum(weighted_values, dim=1)
        return output

#增加多头注意力机制
class MultiHeadGATModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_heads):
        super(MultiHeadGATModel, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.w = nn.Parameter(torch.Tensor(num_heads, input_dim, hidden_dim))
        # 创建多个注意力头
        self.attention_heads = nn.ModuleList([
            nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LeakyReLU(negative_slope=0.2),
                nn.Softmax(dim=-1),
            ) for _ in range(num_heads)
        ])
        nn.init.xavier_uniform_(self.w, gain=1.414)

    def forward(self, x, adj_matrix):
        x = x.reshape(-1, self.input_dim)  # Flatten the input tensor
        attention_weights = torch.stack([head(x) for head in self.attention_heads], dim=2)
        adjacency_matrix_expanded = adj_matrix.unsqueeze(0).repeat(x.shape[0], 1, 1)
        weighted_values = torch.matmul(attention_weights,adjacency_matrix_expanded)
        return torch.sum(weighted_values, dim=2)

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])  # 只使用序列的最后一个时间步作为预测
        return out

# 训练多头注意力的GAT模型
def train_multihead_gat_model(model, data, adj_matrix, num_epochs=1000, lr=0.01):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for epoch in range(num_epochs):
        optimizer.zero_grad()
        output = model(data, adj_matrix)
        output = output.view(len(data),int(output.shape[0]/len(data)),output.shape[1])
        loss = criterion(output, data.repeat(1,1,8))
        loss.backward()
        optimizer.step()
    return model

# 可视化权重分布（多头注意力）
def hiatus_attention_weights(model, data,data2,adj_matrix):
    with torch.no_grad():
        model.eval()
        output = model(data, adj_matrix)
        output2 = model(data2, adj_matrix)
        attention_weights = torch.stack([head(data[:, -1]) for head in model.attention_heads], dim=1)
        attention_weights2 = torch.stack([head(data2[:, -1]) for head in model.attention_heads], dim=1)
        # print("Multi-Head Attention Features:")
        # print(attention_weights)

        # plt.figure(figsize=(10, 6))
        # for i in range(model.num_heads):
        #     for j in range(num_nodes):
        #         plt.plot(range(302), attention_weights[:, i, j], label=f"Head {i+1}, Node {j+1}")
        # plt.xlabel("Trajectory Index")
        # plt.ylabel("Attention Weight")
        # plt.title("Multi-Head Attention Weight Distribution for Each Node")
        # plt.legend()
        # plt.show()
        kk = attention_weights.numpy()
        kkk = attention_weights2.numpy()
        P = caculate(kk,kkk,data)
        local = P.index(max(P))
        return kkk[local]

# 设置模型参数
def k_means(data,k):
    data = np.array([matrix.flatten() for matrix in data])
    kmeans = KMeans(n_clusters=k)
    kmeans.fit(data)
    # 获取聚类结果，每个样本的标签
    labels = kmeans.labels_
    for i in range(k):
        cluster_data = data[labels == i]
        print(f"类别 {i + 1} 包含 {len(cluster_data)} 个样本")
    centers = kmeans.cluster_centers_
    print("聚类中心点:",centers)

def caculate(kk,kkk,data):
    u = np.sum(kk,0)
    u = np.divide(u,len(data))
    hei,row,col = kk.shape
    a = 0
    for i in range(hei):
        a = a + np.linalg.norm(kk[i]-u, ord=2, axis=None, keepdims=False)
    o2 = a/len(data)
    l = []
    hei, row, col = kkk.shape
    for i in range(hei):
        l.append(1/(math.sqrt(2*math.pi*o2))*math.exp(-np.linalg.norm(kkk[i]-u, ord=2, axis=None, keepdims=False)/(2*o2)))
    return l