import random
import numpy as np
import pandas as pd
from collections import OrderedDict
#num:丢失人的id,de:此人删除的坐标序号,real:真实值
#n:该行人坐标值总数,train_ped_h:所有行人的id,train_ped_dic:所有行人的坐标序列
ped_list = []  # 元素是数字，行人id
ped_list_data = []  # 元素是列表，行人
frame_list = [] #帧列表
all_frame_data = []  # 元素为列表
valid_frame_data = []  # 元素为列表
numFrame_data = []  # 元素为数字
frameped_dict = {}  # 字典，帧号：id
pedtrajec_dict = {}  # 字典，行人：np数组，数组元素为列表，列表元素为[帧,x,y]
train_ped = []
test_ped = []
real = []

def dataloader():
    fdata = pd.read_csv('D:\pythonproject\SGmodel\data\eth\hotel\\true_pos_.csv',header=None)  # 读入数据

    data = np.genfromtxt('D:\pythonproject\SGmodel\data\eth\hotel\\true_pos_.csv', delimiter=',')
    #统计行人id和个数
    ped_list = np.unique(data[1, :]).tolist()
    nPed = len(ped_list)
    ped_list_data.append(ped_list)

    all_frame_data.append([])
    valid_frame_data.append([])
    for i,pedi in enumerate(ped_list):
        FrameContainPed = data[:, data[1, :] == pedi]#既包含坐标又包含帧号的行人的数据
        FrameList = FrameContainPed[0, :].tolist()#获取每个行人有坐标的帧号
        if len(FrameList)<2:
            continue
        else:
            numFrame_data.append(len(FrameList))#将所有坐标不为1帧的有记载每个行人的帧数统计下来
        Trajectories = []
        for fi, frame in enumerate(FrameList):
            current_x = FrameContainPed[3, FrameContainPed[0, :] == frame][0]
            current_y = FrameContainPed[2, FrameContainPed[0, :] == frame][0]#获取当前帧的坐标
            Trajectories.append([int(frame), current_x, current_y])#格式为：[帧号，x，y]
            if int(frame) not in frameped_dict:
                frameped_dict[int(frame)] = []
            frameped_dict[int(frame)].append(pedi)#将帧号和对应的行人id组合成字典的形式即：{帧号:[id1,id2,id3]，帧号:[id1,id2,id3]}
        pedtrajec_dict[pedi] = np.array(Trajectories)

    list1 = list(pedtrajec_dict.keys())
    # 把凡是有空坐标的行人删除
    dele = []
    for i in range(len(list1)):
        arr = pedtrajec_dict[list1[i]]
        flag = 0
        for l in arr:
            for el in l:
                if el is None or np.isnan(el):
                    flag = 1
                    break
        if flag == 1:
            dele.append(list1[i])
    for i in dele:
        list1.remove(i)
    #划分测试集训练集
    train_ped = list1[:int(len(list1) * 0.8)]
    test_ped = list1[int(len(list1) * 0.8):]
    print('proprecess data over!')
    return train_ped,test_ped

    #输入：每个人一个lstm训练时间序列，n个人[x,y]为一个元素，m个[x,y]

#随机丢失帧函数
def hiatus_train(data):
    train_ped_h = data #训练轨迹
    train_p_t = {} #
    for index, key in enumerate(train_ped_h):
        if key not in train_p_t:
            train_p_t[key]=pedtrajec_dict[key]
    num = random.choice(train_ped_h)
    length = len(pedtrajec_dict[num])
    de = random.randint((int)(length/3*2),length)
    if de > length:
        de = length - 2
    for ind,ele in enumerate(pedtrajec_dict[num]):
        if ind == de:
            real.append([ele[1],ele[2]])
            ele[1] = None
            ele[2] = None
            print('random hiatus has been done!')
            break
    return real,num,de,train_ped_h,train_p_t

def hiatus_test(data):
    test_ped_h = data
    test_p_t = {}
    for index, key in enumerate(test_ped_h):
        if key not in test_p_t:
            test_p_t[key]=pedtrajec_dict[key]
    num = random.choice(test_ped_h)
    length = len(pedtrajec_dict[num])
    de = random.randint((int)(length/3*2), length)
    for ind,ele in enumerate(pedtrajec_dict[num]):
        if ind == de:
            real.append([ele[1],ele[2]])
            ele[1] = None
            ele[2] = None
            break
    return real,num,de,test_ped_h,test_p_t

#判断是不是行人邻居（
def neighbor(t,num,de,ped_h,ped_dic):
    #print(num)
    #print(ped_h) 行人id
    #print(ped_dic) 行人：np数组(帧、x、y)
    for i,index in ped_list:
        print(inputnodes)
    num_Peds = inputnodes.shape[1]#输入的是当前行人的节点
    print(num_Peds)
    seq_list = np.zeros((inputnodes.shape[0], num_Peds))
    #denote where data not missing
    print(seq_list)

    for pedi in range(num_Peds):
        seq = inputnodes[:, pedi]
        seq_list[seq[:, 0] != 0, pedi] = 1

    # get relative cords, neighbor id list
    nei_list = np.zeros((inputnodes.shape[0], num_Peds, num_Peds))
    nei_num = np.zeros((inputnodes.shape[0], num_Peds))

    # nei_list[f,i,j] denote if j is i's neighbors in frame f
    for pedi in range(num_Peds):
        nei_list[:, pedi, :] = seq_list
        nei_list[:, pedi, pedi] = 0  # person i is not the neighbor of itself
        nei_num[:, pedi] = np.sum(nei_list[:, pedi, :], 1)
        seqi = inputnodes[:, pedi]
        for pedj in range(num_Peds):
            seqj = inputnodes[:, pedj]
            select = (seq_list[:, pedi] > 0) & (seq_list[:, pedj] > 0)

            relative_cord = seqi[select, :2] - seqj[select, :2]

            # invalid data index
            select_dist = (abs(relative_cord[:, 0]) > self.args.neighbor_thred) | (
            abs(relative_cord[:, 1]) > self.args.neighbor_thred)

            nei_num[select, pedi] -= select_dist

            select[select == True] = select_dist
            nei_list[select, pedi, pedj] = 0
    return seq_list, nei_list, nei_num

def loss():
    return 0
